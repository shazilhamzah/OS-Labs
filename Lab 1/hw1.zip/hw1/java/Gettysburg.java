/* Marty Stepp, CSE 142, Autumn 2008
This program prints some words from Abe Lincoln's
Gettysburg Address. */

public class Gettysburg {
	public static void main(String[] args) {
		System.out.println("This program prints a");
		System.out.println("quote from the Gettysburg Address.");
		System.out.println();
		
		booyah();
		booyah();
		
		System.out.println("\"Four score and seven years ago,");
		System.out.println("our 'fore fathers' brought forth on");
		System.out.println("this continent a new nation.\"");

		booyah();
	}
	
	public static void booyah() {
		System.out.println("This product causes cancer");
		System.out.println("In rats and freshmen.");
	}
}
