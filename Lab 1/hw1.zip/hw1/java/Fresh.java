public class Fresh {
    public static void main(String[] args) {
        System.out.println("Now this is the story all about how,");
        System.out.println("My life got flipped, turned upside down,");
        System.out.println("And I'd like to take a minute, just sit right there,");
        System.out.println("I'll tell you how I became the prince of a town called Bel Air.");
        System.out.println();
        System.out.println("In West Philadelphia, born and raised");
        System.out.println("On the playground is where I spent most of my days.");
        System.out.println("Chillin' out, maxin', relaxin all cool,");
        System.out.println("And all shootin' some b-ball outside of the school.");
        System.out.println();
        System.out.println("When a couple of guys who were up to no good,");
        System.out.println("Started makin' trouble in my neighborhood.");
        System.out.println("I got in one little fight and my mom got scared,");
        System.out.println("And said You're movin' with your auntie and uncle in Bel Air.");
        System.out.println();
        System.out.println("Well, I whistled for a cab, and when it came near,");
        System.out.println("The license plate said fresh and it had dice in the mirror.");
        System.out.println("If anything I could say that this cat was rare,");
        System.out.println("But I thought Nah forget it, \"Yo homes, to Bel Air.\"");
        System.out.println();
        System.out.println("I pulled up to the house about seven or eight,");
        System.out.println("and I yelled to the cabby \"Yo homes, smell ya later.\"");
        System.out.println("Looked at my kingdom, I was finally there,");
        System.out.println("To sit on my throne as the Prince of Bel Air.");
    }
}
